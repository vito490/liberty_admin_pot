#Mon Nov 07 23:07:16 GMT 2022
lib/platform/defaultLogging-1.0.mf=5dca00ad3a1c72fd06670dc28717f34f
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.logging_1.1-javadoc.zip=217288e4050479bc27f7c9805324ae9f
dev/spi/ibm/com.ibm.websphere.appserver.spi.logging_1.1.71.jar=7886e89ad6a00b1569690295d739ca32
lib/com.ibm.ws.collector.manager_1.0.71.jar=16bfdba33cfc32e456da6c02122ac5f5
lib/com.ibm.ws.logging_1.0.71.jar=83c6f9f22a805ec483e7833ce1eaf1fe
lib/com.ibm.ws.logging.osgi_1.0.71.jar=a056af5a8d811c5b771c585c48417036
