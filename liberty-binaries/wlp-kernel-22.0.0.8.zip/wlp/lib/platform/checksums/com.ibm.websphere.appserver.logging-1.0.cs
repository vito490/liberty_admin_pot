#Tue Jul 19 14:34:31 BST 2022
lib/platform/defaultLogging-1.0.mf=5dca00ad3a1c72fd06670dc28717f34f
lib/com.ibm.ws.logging_1.0.67.jar=cfd836c78c7afea73bdb5ce31a8cfe36
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.logging_1.1-javadoc.zip=fa2bf343744505fc9bc99ad10f031622
lib/com.ibm.ws.logging.osgi_1.0.67.jar=186f6300e5b2cb1e21cdbe7307a3dacf
dev/spi/ibm/com.ibm.websphere.appserver.spi.logging_1.1.67.jar=7ec5f134efcda2953192f0d3711e5457
lib/com.ibm.ws.collector.manager_1.0.67.jar=94aaba87fb4db575d9b220e02a133978
